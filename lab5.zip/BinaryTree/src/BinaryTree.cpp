#include "BinaryTree.hpp"

#include <algorithm>
#include <iostream>
#include <random>
#include <sstream>
#include <stdexcept>

// Destructor: Cleans up the tree
BinaryTree::~BinaryTree() { destroyTree(root_); }

// Shared random number generator
std::mt19937& BinaryTree::rng() {
    static std::mt19937 eng{std::random_device{}()};
    return eng;
}

// Recursively deletes all nodes in the tree
void BinaryTree::destroyTree(Node* x) {
    // TODO: Implement this method to clean up the tree
    if(x == nullptr){
        return;
    }
    destroyTree(x -> left);
    destroyTree(x -> right);
    delete x;
}

// Returns the number of nodes in the tree
int BinaryTree::getSize() const { 
    if (treeType_ == TreeType::HEAP) {
        return static_cast<int>(heapArray_.size()) - 1;
    }
    return calculateSize(root_); 
}

// Helper: Recursively calculates the size of the tree
int BinaryTree::calculateSize(Node* x) const {
    // TODO: Implement this method to calculate the size of the tree
    if(x == nullptr){
        return 0;
    }
    return 1 + calculateSize(x -> left) + calculateSize(x -> right);
}

// Returns the height of the tree
int BinaryTree::getHeight() const { return calculateHeight(root_); }

int BinaryTree::calculateHeight(Node* x) const {
    // TODO: Implement this method to calculate the height of the tree
    if(x == nullptr){
        return -1;
    }
    return 1 + std::max(calculateHeight(x -> left), calculateHeight(x -> right));
}

// Inserts an item into the tree
void BinaryTree::insert(int item) {
    switch (treeType_) {
        case TreeType::BST:
            {
                Node* newNode = insertBST(root_, item);
                if (!root_) root_ = newNode;
            }
            break;
        case TreeType::HEAP:
            {
                insertHeapArray(item);
                arrayToTree(); // Update tree representation
            }
            break;
        default:
            {
                Node* newNode = insertBST(root_, item);
                if (!root_) root_ = newNode;
            }
            break;
    }
}

// Heap insertion using array representation
void BinaryTree::insertHeapArray(int item) {
    // TODO: Implement this method to insert into the heap array
    if(heapArray_.empty()){
        heapArray_.push_back(0);
    }
    heapArray_.push_back(item);
    int index = heapArray_.size() - 1;
    swimArray(index);
}

// Swim up operation for array-based heap
void BinaryTree::swimArray(int index) {
    // TODO: Implement this method to maintain heap property after insertion
    while(index > 1){
        int parent = index / 2;
        if(heapArray_[parent] >= heapArray_[index]){
            break;
        }
        std::swap(heapArray_[parent], heapArray_[index]);
        index = parent;
    }
}

// Delete maximum element from heap
int BinaryTree::deleteMax() {
    if (treeType_ != TreeType::HEAP) {
        throw std::runtime_error("deleteMax() can only be called on HEAP trees");
    }
    if (heapArray_.size() <= 1) {
        throw std::runtime_error("Heap is empty");
    }
    
    int maxValue = deleteMaxArray();
    arrayToTree(); // Update tree representation
    return maxValue;
}

// Classical heap deleteMax using array representation
int BinaryTree::deleteMaxArray() {
    // TODO: Implement this method to delete the maximum element from the heap array
    int value = heapArray_[1];
    int lastIndex = heapArray_.size() - 1;

    if(heapArray_.size() <= 1){
        throw std::runtime_error("Empty heap");
    }

    heapArray_[1] = heapArray_[lastIndex];
    heapArray_.pop_back();

    if(heapArray_.size() > 1){
        sinkArray(1);
    }
    return value;
}

// Sink down operation for array-based heap
void BinaryTree::sinkArray(int index) {
    // TODO: Implement this method to maintain heap property after deletion
    int n = heapArray_.size() - 1;
    while(2 * index < n){
        int left = index * 2;
        int right = left + 1;
        int largeIndex = left;

        if(right <= n && heapArray_[left] < heapArray_[right]){
            largeIndex = right;
        }

        if(heapArray_[index] >= heapArray_[largeIndex]) {
            break;
        }

        std::swap(heapArray_[index], heapArray_[largeIndex]);
        index = largeIndex;
    }
}

// Peek at maximum element without removing it
int BinaryTree::peekMax() const {
    if (treeType_ != TreeType::HEAP) {
        throw std::runtime_error("peekMax() can only be called on HEAP trees");
    }
    
    if (static_cast<int>(heapArray_.size()) <= 1) {
        throw std::runtime_error("Heap is empty");
    }
    
    return heapArray_[1];
}

// Performs heap sort and returns sorted values in ascending order
std::vector<int> BinaryTree::heapSort() {
    // TODO: Implement this method to perform heap sort and return sorted values
    if(treeType_ != TreeType::HEAP) {
        throw std::runtime_error("heapSort() can only be called on HEAP trees");
    }

    if(heapArray_.size() <= 1) {
        return {};
    }

    std::vector<int> heapCopy = heapArray_;
    int n = heapCopy.size() - 1;
    std::vector<int> result;

    auto sinkLocal = [&](int index, int heapSize) {
        while(2 * index <= heapSize) {
            int left = 2 * index;
            int right = left + 1;
            int largerChild = left;

            if(right <= heapSize && heapCopy[right] > heapCopy[left]) {
                largerChild = right;
            }

            if(heapCopy[index] >= heapCopy[largerChild]) break;

            std::swap(heapCopy[index], heapCopy[largerChild]);
            index = largerChild;
        }
    };

    while(n > 1) {
        std::swap(heapCopy[1], heapCopy[n]);
        result.push_back(heapCopy[n]);
        --n;
        sinkLocal(1, n);
    }

    result.push_back(heapCopy[1]);

    std::reverse(result.begin(), result.end());
    return result;
}


// Convert heap array to tree representation
void BinaryTree::arrayToTree() {
    if (treeType_ != TreeType::HEAP) return;
    
    // Clear existing tree
    destroyTree(root_);
    root_ = nullptr;
    
    // Build tree from array (starting from index 1)
    if (static_cast<int>(heapArray_.size()) > 1) {
        root_ = arrayToTreeHelper(1);
    }
}

// Helper: Recursively build tree from array
BinaryTree::Node* BinaryTree::arrayToTreeHelper(int index) {
    // TODO: Implement this method to build tree from heap array
    if(index >= static_cast<int>(heapArray_.size())){
        return nullptr;
    }

    Node* node = new Node(heapArray_[index]);
    node->left = arrayToTreeHelper(index * 2);
    node->right = arrayToTreeHelper(index * 2 + 1);

    return node;
}

// Helper: Recursively inserts a node into BST
BinaryTree::Node* BinaryTree::insertBST(Node* x, int item) {
    // TODO: Implement this method to insert into the BST
    if(x == nullptr){
        return new Node(item);
    }
    if(item < x -> item){
        x -> left = insertBST(x -> left, item);
    }else if( item > x -> item){
        x -> right = insertBST(x -> right, item);
    }
    return x;
}

// Finds a node with the given item in BST
BinaryTree::Node* BinaryTree::findBST(Node* x, int item) const {
    // TODO: Implement this method to find a node in the BST
    if(x == nullptr){
        return nullptr;
    }
    if(item == x -> item){
        return x;
    }else if(item < x -> item){
        return findBST(x -> left, item);
    }else{
        return findBST(x -> right, item);
    }
}

// Helper: Recursively finds a node in a heap
BinaryTree::Node* BinaryTree::findHeap(Node* node, int item) const {
    // TODO: Implement this method to find a node in the heap tree
    if(node == nullptr) {
        return nullptr;
    }
    if(node->item == item) {
        return node;
    }
    Node* leftFound = findHeap(node->left, item);

    if(leftFound != nullptr) {
        return leftFound;
    }

    return findHeap(node->right, item);
}

// Finds a node with the given item
BinaryTree::Node* BinaryTree::findNode(int item) const {
    switch (treeType_) {
        case TreeType::BST:
            return findBST(root_, item);
        case TreeType::HEAP:
            return findHeap(root_, item);
        default:
            return nullptr;
    }
}

// Visualizes the tree level by level
std::string BinaryTree::visualizeTree() const {
    std::ostringstream oss;

    if (!root_) return "Tree is empty.\n";

    oss << "Tree Visualization (Level Order):\n";
    
    // For heap, also show array representation
    if (treeType_ == TreeType::HEAP && static_cast<int>(heapArray_.size()) > 1) {
        oss << "Heap Array: [";
        for (int i = 1; i < static_cast<int>(heapArray_.size()); i++) {
            oss << heapArray_[i];
            if (i < static_cast<int>(heapArray_.size()) - 1) oss << ", ";
        }
        oss << "]\n";
    }
    
    std::queue<Node*> q;
    q.push(root_);

    while (!q.empty()) {
        int levelSize = static_cast<int>(q.size());

        for (int i = 0; i < levelSize; ++i) {
            Node* current = q.front();
            q.pop();

            if (current) {
                oss << current->item << " ";
                q.push(current->left);
                q.push(current->right);
            } else {
                oss << "null ";
            }
        }

        oss << "\n";
    }

    return oss.str();
}


// Creates a tree with random integers
BinaryTree BinaryTree::createRandomTree(int nodes) {
    BinaryTree tree;
    std::uniform_int_distribution<int> dist(0, RAND_INT_BOUND - 1);
    auto& eng = rng();
    for (int i = 0; i < nodes; ++i) tree.insert(dist(eng));
    return tree;
}

// Analyzes tree heights for random trees
void BinaryTree::analyzeRandomTreeHeights(int nodes, int trees) {
    int minHeight = RAND_INT_BOUND + 1;
    int maxHeight = 0;
    long long sum = 0;

    for (int i = 0; i < trees; ++i) {
        int height = createRandomTree(nodes).getHeight();
        minHeight = std::min(minHeight, height);
        maxHeight = std::max(maxHeight, height);
        sum += height;
    }

    int avgHeight = trees ? static_cast<int>(sum / trees) : 0;
    std::cout << trees << " " << nodes << "-node trees: "
              << "min_height=" << minHeight
              << ", max_height=" << maxHeight
              << ", avg_height=" << avgHeight << "\n";
}

// Returns BST values in sorted ascending order
std::vector<int> BinaryTree::bstSort() const {
    if (treeType_ != TreeType::BST) {
        throw std::runtime_error("bstSort() can only be called on BST trees");
    }
    
    std::vector<int> sortedValues;
    bstSortHelper(root_, sortedValues);
    return sortedValues;
}

// Helper: Recursively traverse BST to get sorted values
void BinaryTree::bstSortHelper(Node* node, std::vector<int>& sortedValues) const {
    // TODO: Implement this method to get sorted values from BST nodes
    if(node == nullptr){
        return;
    }
    bstSortHelper(node -> left, sortedValues);
    sortedValues.push_back(node -> item);
    bstSortHelper(node -> right, sortedValues);
}
